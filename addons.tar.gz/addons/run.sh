#!bin/bash

mkfifo fifo.hepmc
less /nfs/dust/cms/user/duerrm/data/MonoDarkHiggs/signal/Events/run_174.hepmc.gz  >> fifo.hepmc & 
rivet -a FatHiggsTagging --process higgs -o higgs_100_2000_65.yoda fifo.hepmc


